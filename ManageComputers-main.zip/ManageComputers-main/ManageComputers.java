//Manage Computers program: maintains an ArrayList of Computer objects, 
//can be either Laptop or Desktop, but never just Computer-type objects themselves
//@chelseayang: edited desktop GPU options

import java.util.ArrayList;
import java.util.Scanner;

/**
 * ManageComputers.java
 * 
 * Changelog:
 * updated by @author quanhuynh11
    * - Storing computers in an ArrayList of type object instead of ArrayList of type Computer
    * because we switched to composition, and all of the computers not inheriting from Computer anymore
 * 
    * - We are now replacing the current object in the editComputer method with a new object of the same type
    * to follow immutable principles

 * @version 1.1
 */
public class ManageComputers {

    public static void main(String args[]) {
        /**
         * Since we changed to using composition
         * we will have to store them in an ArrayList of type object
         * @quanhuynh11
         */
        ArrayList<Object> computers = new ArrayList<Object>();

        Scanner s = new Scanner(System.in);
        String menuOption = "";

        do { // Start of main program loop

            // Show computer data in ArrayList<Computer>
            showComputers(computers);

            // Display menu and return menu option selected by the user
            menuOption = getMenuSelection(s);

            switch (menuOption) {
                // Add new computer
                case "a":

                    addComputer(computers, s);

                    break;

                // Delete a computer
                case "d":

                    deleteComputer(computers, s);

                    break;

                // Edit a computer
                case "e":

                    editComputer(computers, s);

                    break;
            }

        } while (!menuOption.equals("x")); // Stop when "x" is entered

        s.close(); // Close keyboard scanner

    } // End of main

    // -----------------------------
    // Display menu and get user selection, return it
    private static String getMenuSelection(Scanner s) {
        String menuOption = "";

        // Display menu options on-screen
        System.out.println("----------");
        System.out.println("A) Add Computer");
        System.out.println("D) Delete Computer");
        System.out.println("E) Edit Computer");
        System.out.println("X) eXit");
        System.out.println("----------");

        // Get menu selection from keyboard
        System.out.print("Enter menu selection: ");
        menuOption = s.nextLine();

        menuOption = menuOption.toLowerCase(); // Make lower case for comparison purposes

        return menuOption;
    } // End of getMenuSelection

    // -----------------------------
    // Show data for all laptops and desktops stored in ArrayList<Computer> create
    // in main() method
    private static void showComputers(ArrayList<Object> computers) {
        int computerListNumber = 0; // This variable is used to hold the "list number" for each computer, starting
                                    // at 1.

        System.out.println("=========");

        System.out.println("LIST OF COMPUTERS:-");

        for (Object c : computers) {

            computerListNumber++; // Increment list number for each computer

            // Call overridden toString() method for current object to get and display its
            // data
            System.out.println(computerListNumber + ": " + c.toString());
        }

        System.out.println("=========");

    } // End of showComputers

    // -----------------------------
    // Add a new Laptop or Desktop computer to the ArrayList<Computer>
    private static void addComputer(ArrayList<Object> computers, Scanner s) {
        String computerType = "";

        Computer tempComputer = null;

        System.out.println("ADDING COMPUTER:-");

        System.out.println("Enter type of computer to add ('L' for Laptop, 'D' for Desktop): ");
        computerType = s.nextLine();
        computerType = computerType.toLowerCase(); // Convert to lower case for comparison purposes

        switch (computerType) {

            // Add a laptop
            case "l":

               tempComputer = getComputerData(s);
   
               System.out.print("Enter screen size (Valid: 13, 14): ");
               String screenSize = s.nextLine();
               while (!screenSize.equals("13") && !screenSize.equals("14")) {
            	   System.out.print("Invalid input! Enter a valid screen size (13, 14): ");
            	   screenSize = s.nextLine();
               }// @Tokorio
   
               computers.add(new Laptop(tempComputer.getCPU(), tempComputer.getRAM(), tempComputer.getDisk(), screenSize));

                break;

            // Add a desktop
            case "d":

                tempComputer = getComputerData(s);

               System.out.print("Enter GPU (Valid: Nvidia, AMD):");
               String GPUType = s.nextLine();
               while (!GPUType.equalsIgnoreCase("Nvidia") && !GPUType.equalsIgnoreCase("AMD")) {
                   System.out.print("Invalid input! Enter a valid GPU (Nvidia, AMD): ");
                   GPUType = s.nextLine();
               }// @Tokorio
   
               computers.add(new Desktop(tempComputer.getCPU(), tempComputer.getRAM(), tempComputer.getDisk(), GPUType));
               break;

            // Invalid computer type to add entered
            default:

                System.out.println("Invalid computer type entered!");
        }
        
    } // End of addComputer

    // -----------------------------
    // Delete a specified computer from the ArrayList
    private static void deleteComputer(ArrayList<Object> computers, Scanner s) {
        int computerListNumberToDelete = 0;

        System.out.println("DELETE COMPUTER:-");

        System.out.print("Enter number of computer to delete: ");
        computerListNumberToDelete = Integer.parseInt(s.nextLine());

        // Check if computer list number is valid before deleting computer from list
        if (computerListNumberToDelete >= 1 && computerListNumberToDelete <= computers.size()) {
            // Subtract 1 to get ArrayList index from on-screen list number to create
            // correct index in ArrayList to delete
            computers.remove(computerListNumberToDelete - 1);
        } else {
            System.out.println("Invalid computer number entered!");
        }

    } // End of deleteComputer

    // -----------------------------
    // Edit a computer. Since Laptop and Desktop are mutable classses/object get new
    // data values and replace old
    // attribute values in object being edited using object setter methods
    private static void editComputer(ArrayList<Object> computers, Scanner s) {
        int computerListNumberToEdit = 0;
        String computerType = "";
        Computer tempComputer = null;

        System.out.println("EDIT COMPUTER:-");

        System.out.print("Enter number of computer to edit: ");
        computerListNumberToEdit = Integer.parseInt(s.nextLine());

        // Check that computerListNumberToEdit is valid first
        if (computerListNumberToEdit >= 1 && computerListNumberToEdit <= computers.size()) {

            // Determine exact type of computer being edited
            // Subtract 1 to get ArrayList index from on-screen list number
            if (computers.get(computerListNumberToEdit - 1) instanceof Laptop) {
                computerType = "laptop";
            }
            // Subtract 1 to get ArrayList index from on-screen list number
            else if (computers.get(computerListNumberToEdit - 1) instanceof Desktop) {
                computerType = "desktop";
            }

            // Edit computer
            switch (computerType) {

                // Editing a laptop
                case "laptop":

                    System.out.println("Editing a Laptop: ");

                    // Get CPU, RAM and Disk info, store in temporary Computer-type object
                    tempComputer = getComputerData(s);

                    System.out.print("Enter screen size:");
                    String screenSize = s.nextLine();
                    while (!screenSize.equals("13") && !screenSize.equals("14") ) {
                       System.out.print("Invalid input! Enter a valid screen size (13, 14): ");
                       screenSize = s.nextLine();
                    } //@Tokorio
                    /**
                     * Replace the laptop object in the computers ArrayList with a new
                     * laptop object with the new data
                     * @quanhuynh11
                     */
                    computers.set(computerListNumberToEdit - 1, new Laptop(tempComputer.getCPU(), tempComputer.getRAM(),
                            tempComputer.getDisk(), screenSize));
                    break;

                // Editing a desktop, store in temporary Computer-type object
                case "desktop":

                    System.out.println("Editing a Desktop: ");

                    // Get CPU, RAM and Disk info
                    tempComputer = getComputerData(s);

                    System.out.print("Enter GPU: ");
                    String GPUType = s.nextLine();
                    while (!GPUType.equalsIgnoreCase("Nvidia") && !GPUType.equalsIgnoreCase("AMD")) {
                       System.out.print("Invalid input! Enter a valid GPU (Nvidia, AMD): ");
                       GPUType = s.nextLine();
                    }// @Tokorio
                    /**
                     * Replace the desktop object in the computers ArrayList with a new
                     * desktop object with the new data
                     * @quanhuynh11
                     */
                    computers.set(computerListNumberToEdit - 1, new Desktop(tempComputer.getCPU(), tempComputer.getRAM(),
                            tempComputer.getDisk(), GPUType));

                    break;
            }

        } else {
            System.out.println("Invalid computer number entered!");
        }

    } // End of editComputer

    // -----------------------------
    // Helper method to get data common to Laptop and Desktop (CPU, RAM and disk)
    // objects. Returns a Computer-type object
    // holding these values as attribues
    private static Computer getComputerData(Scanner s) {
        String CPU = "";
        String RAM = "";
        String disk = "";

        System.out.print("Enter CPU:");
        CPU = s.nextLine();
        while (!CPU.equals("i5") && !CPU.equals("i7")) {
            System.out.print("Reenter CPU. Valid options are i5 and i7: "); 
            CPU = s.nextLine();      	
        }

        System.out.print("Enter RAM: ");
        RAM = s.nextLine();
        while (!RAM.equals("16") && !RAM.equals("32")) {
            System.out.print("Reenter RAM. Valid options are 16 and 32: "); 
            RAM = s.nextLine();      	
        }

        System.out.print("Enter Disk:");
        disk = s.nextLine();
        while (!disk.equals("512") && !disk.equals("1024")) {
            System.out.print("Reenter disk. Valid options are 512 and 1024: "); 
            disk = s.nextLine();      	
        }

        return new Computer(CPU, RAM, disk);

    } // End of getComputerData

} // End of ManageComputer class
