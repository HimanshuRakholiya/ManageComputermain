//Laptop computer: adds screen size to other Computer info
//@fernandocbhorta: Deleted setter and added private final to Computer, String variables
//@chelseayang: Edited toString() format to look better

public class Laptop {
    private final Computer computer;
    private final String screenSize;

    // Constructors
    // public Laptop() {
    // this.computer = new Computer();
    // this.screenSize = null;
    // }

    public Laptop(String CPU, String RAM, String disk, String screenSize) {
        this.computer = new Computer(CPU, RAM, disk);
        this.screenSize = screenSize;
    }

    // Getter for screenSize
    public String getScreenSize() {
        return this.screenSize;
    }

    // Return formatted version of data
    public String toString() {
    	if (this.computer.getDisk().equals("1024")) {
     	   return "Type:Laptop\tCPU:" + this.computer.getCPU() + "\tRAM:" + this.computer.getRAM() + "\tDisk:"
                    + this.computer.getDisk() + "\tScreen:" + this.screenSize;
        }
        else {
     	   return "Type:Laptop\tCPU:" + this.computer.getCPU() + "\tRAM:" + this.computer.getRAM() + "\tDisk:"
                    + this.computer.getDisk() + "\t\tScreen:" + this.screenSize;
        }	
    }
}