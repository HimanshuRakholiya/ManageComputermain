//Desktop computer: adds GPU type
//@fernandocbhorta: Deleted setter and added private final to Computer, String variables
//@chelseayang: Edited toString() format to look better

public class Desktop {
    private final Computer computer;
    private final String GPUType;

    // Constructors
    // public Desktop() {
    // this.computer = new Computer();
    // this.GPUType = null;
    // }

    public Desktop(String CPU, String RAM, String disk, String GPUType) {
        this.computer = new Computer(CPU, RAM, disk);
        this.GPUType = GPUType;
    }

    // Getter for GPUType
    public String getGPUType() {
        return this.GPUType;
    }

    // Return formatted version of data
    public String toString() {
    	if (this.computer.getDisk().equals("1024")) {
        	return "Type:Desktop\tCPU:" + this.computer.getCPU() + "\tRAM:" + this.computer.getRAM() + "\tDisk:"
                    + this.computer.getDisk() + "\tGPU:" + this.GPUType;
        }
        else {
        	return "Type:Desktop\tCPU:" + this.computer.getCPU() + "\tRAM:" + this.computer.getRAM() + "\tDisk:"
                    + this.computer.getDisk() + "\t\tGPU:" + this.GPUType;
        }
    }
}
